package com.example.petstore.swagger;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface JSONApi {

    //https://petstore.swagger.io/v2/   swagger.json

    @GET("/pet/{id}")
    Call<Pet> getPet(@Path("id") String id);

    Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("https://petstore.swagger.io/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    @POST("pet")
    Call<Pet> createPet(@Body Pet pet);

    Retrofit retrofit2 = new Retrofit.Builder()
            .baseUrl("https://petstore.swagger.io/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();
}
