package com.example.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.petstore.swagger.Category;
import com.example.petstore.swagger.Pet;
import com.example.petstore.swagger.JSONApi;
import com.example.petstore.swagger.Tag;
import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    EditText editText;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {

        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.edText);
        imageView = findViewById(R.id.imageView);
        String path = String.valueOf(editText.getText());

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://petstore.swagger.io/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JSONApi jsonApi = retrofit.create(JSONApi.class);

        Call<Pet> call = jsonApi.getPet(path);

        call.enqueue(new Callback<Pet>() {
            @Override
            public void onResponse(Call<Pet> call, Response<Pet> response) {
                if(response.isSuccessful()) {
                    textView.setText(String.valueOf(response.code()));
                    return;
                }
                Pet pet = response.body();
                Category category = pet.getCategory();
                List<Tag> tagList = pet.getTag();
                Tag tag = tagList.get(0);
                String content = "";
                content += "Вашего питомца зовут: " + String.valueOf(pet.getPetName()) +
                        "\nВид вашего питомца - " + String.valueOf(category.getCategoryName()) +
                        "\nСтатус: " + String.valueOf(tag.getName());
                textView.setText(content);
                /* List<String> photoURLS = pet.getPhotoUrls();
                String photoURL = photoURLS.get(0);
                Picasso.get().load(photoURL).into(imageView);*/
            }

            @Override
            public void onFailure(Call<Pet> call, Throwable t) {
                textView.setText("Что-то пошло не так: " + t.getMessage());
            }
        });
    }
}